Thank you for downloading this asset pack. It has been released in to the Public Domain under the Creative Commons CC0 dedication.

You can copy, modify and distribute these assets, even for commercial purposes, all without asking permission.

A written credit is not necessary but always appreciated(!).

mattwalkden.itch.io
mattwalkden.com